#####################################
# THIS FILE DOES NOT NEED TO BE RAN #
# THIS FILE EXISTS TO CREATE FILES  #
# THAT ARE ALREADY PRESENT IN THE   #
# 'MLPROJECT' DIRECTORY. THE FILES  #
# HAVE ALREADY BEEN CREATED         #
#####################################


# importing the libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
np.set_printoptions(precision = 3, suppress = True)


# reading data into dataframes
WBCareer = pd.read_csv('WBCareer.csv')
team2008 = pd.read_csv('team2008.csv')
team2009 = pd.read_csv('team2009.csv')
team2010 = pd.read_csv('team2010.csv')
team2011 = pd.read_csv('team2011.csv')
team2012 = pd.read_csv('team2012.csv')
team2013 = pd.read_csv('team2013.csv')
team2014 = pd.read_csv('team2014.csv')
team2015 = pd.read_csv('team2015.csv')
team2016 = pd.read_csv('team2016.csv')
team2017 = pd.read_csv('team2017.csv')
team2018 = pd.read_csv('team2018.csv')
rockets2018 = pd.read_csv('rockets2018.csv')
WBCareer.drop(WBCareer.tail(1).index,inplace=True)


# converting dataframes to numpy arrays
team2008 = np.array(team2008.values)
team2009 = np.array(team2009.values)
team2010 = np.array(team2010.values)
team2011 = np.array(team2011.values)
team2012 = np.array(team2012.values)
team2013 = np.array(team2013.values)
team2014 = np.array(team2014.values)
team2015 = np.array(team2015.values)
team2016 = np.array(team2016.values)
team2017 = np.array(team2017.values)
team2018 = np.array(team2018.values)
rockets2018 = np.array(rockets2018.values)


# creating empty lists for weights
weights2008 = []
weights2009 = []
weights2010 = []
weights2011 = []
weights2012 = []
weights2013 = []
weights2014 = []
weights2015 = []
weights2016 = []
weights2017 = []
weights2018 = []
weightsRockets = []

# calculating total minutes played for each season
totalMP2008 = sum(team2008[:, 9])
totalMP2009 = sum(team2009[:, 9])
totalMP2010 = sum(team2010[:, 9])
totalMP2011 = sum(team2011[:, 9])
totalMP2012 = sum(team2012[:, 9])
totalMP2013 = sum(team2013[:, 9])
totalMP2014 = sum(team2014[:, 9])
totalMP2015 = sum(team2015[:, 9])
totalMP2016 = sum(team2016[:, 9])
totalMP2017 = sum(team2017[:, 9])
totalMP2018 = sum(team2018[:, 9])
totalMPRockets = sum(rockets2018[:, 9])

# calculating weights for each season 
for x in range(team2008.shape[0]):
    weights2008.append(team2008[x][9] / totalMP2008)
for x in range(team2008.shape[0]):
    weights2009.append(team2009[x][9] / totalMP2009)
for x in range(team2008.shape[0]):
    weights2010.append(team2010[x][9] / totalMP2010)	
for x in range(team2008.shape[0]):
    weights2011.append(team2011[x][9] / totalMP2011)
for x in range(team2008.shape[0]):
    weights2012.append(team2012[x][9] / totalMP2012)
for x in range(team2008.shape[0]):
    weights2013.append(team2013[x][9] / totalMP2013)
for x in range(team2008.shape[0]):
    weights2014.append(team2014[x][9] / totalMP2014)
for x in range(team2008.shape[0]):
    weights2015.append(team2015[x][9] / totalMP2015)
for x in range(team2008.shape[0]):
    weights2016.append(team2016[x][9] / totalMP2016)
for x in range(team2008.shape[0]):
    weights2017.append(team2017[x][9] / totalMP2017)	
for x in range(team2008.shape[0]):
    weights2018.append(team2018[x][9] / totalMP2018)
for x in range(team2008.shape[0]):
    weightsRockets.append(rockets2018[x][9] / totalMPRockets)

# using weights to determine averages
WA2008 = []
for x in range(team2008.shape[1]):
    tempArray = []
    for y in range(team2008.shape[0]):
        tempArray.append(np.multiply(weights2008[y], team2008[y][x]))
    WA2008.append(np.average(tempArray))

WA2009 = []
for x in range(team2008.shape[1]):
    tempArray = []
    for y in range(team2008.shape[0]):
        tempArray.append(np.multiply(weights2009[y], team2009[y][x]))
    WA2009.append(np.average(tempArray))

WA2010 = []
for x in range(team2008.shape[1]):
    tempArray = []
    for y in range(team2008.shape[0]):
        tempArray.append(np.multiply(weights2010[y], team2010[y][x]))
    WA2010.append(np.average(tempArray))

WA2011 = []
for x in range(team2008.shape[1]):
    tempArray = []
    for y in range(team2008.shape[0]):
        tempArray.append(np.multiply(weights2011[y], team2011[y][x]))
    WA2011.append(np.average(tempArray))

WA2012 = []
for x in range(team2008.shape[1]):
    tempArray = []
    for y in range(team2008.shape[0]):
        tempArray.append(np.multiply(weights2012[y], team2012[y][x]))
    WA2012.append(np.average(tempArray))

WA2013 = []
for x in range(team2008.shape[1]):
    tempArray = []
    for y in range(team2008.shape[0]):
        tempArray.append(np.multiply(weights2013[y], team2013[y][x]))
    WA2013.append(np.average(tempArray))

WA2014 = []
for x in range(team2008.shape[1]):
    tempArray = []
    for y in range(team2008.shape[0]):
        tempArray.append(np.multiply(weights2014[y], team2014[y][x]))
    WA2014.append(np.average(tempArray))

WA2015 = []
for x in range(team2008.shape[1]):
    tempArray = []
    for y in range(team2008.shape[0]):
        tempArray.append(np.multiply(weights2015[y], team2015[y][x]))
    WA2015.append(np.average(tempArray))

WA2016 = []
for x in range(team2008.shape[1]):
    tempArray = []
    for y in range(team2008.shape[0]):
        tempArray.append(np.multiply(weights2016[y], team2016[y][x]))
    WA2016.append(np.average(tempArray))

WA2017 = []
for x in range(team2008.shape[1]):
    tempArray = []
    for y in range(team2008.shape[0]):
        tempArray.append(np.multiply(weights2017[y], team2017[y][x]))
    WA2017.append(np.average(tempArray))

WA2018 = []
for x in range(team2008.shape[1]):
    tempArray = []
    for y in range(team2008.shape[0]):
        tempArray.append(np.multiply(weights2018[y], team2018[y][x]))
    WA2018.append(np.average(tempArray))

WARockets = []
for x in range(rockets2018.shape[1]):
    tempArray = []
    for y in range(team2008.shape[0]):
        tempArray.append(np.multiply(weightsRockets[y], rockets2018[y][x]))
    WARockets.append(np.average(tempArray))


# appending each seasons weighted averages to one array
WAmaster = []
WAmaster.append(WA2008)
WAmaster.append(WA2009)
WAmaster.append(WA2010)
WAmaster.append(WA2011)
WAmaster.append(WA2012)	
WAmaster.append(WA2013)	
WAmaster.append(WA2014)
WAmaster.append(WA2015)
WAmaster.append(WA2016)
WAmaster.append(WA2017)
WAmaster.append(WA2018)	

WAmaster = np.array(WAmaster)


# deleting the minutes played column, and changing seasons back to normal
WAmaster = np.delete(WAmaster, 9, axis = 1)
WARockets = np.delete(WARockets, 9)

season = 8
for x in range(WAmaster.shape[0]):
    WAmaster[x][9] = season
    season = season + 1

WARockets[9] = 18


# matching WBCareer to the format of WAmaster
WBCareer = np.array(WBCareer)
WBCareer = np.delete(WBCareer, 9)

print(WARockets)


# appending dependent variables to WAmaster to be exported to CSV files
# PPG
#WAmaster = WAmaster.tolist()
#for x in range(WBCareer.shape[0]):
#    WAmaster[x].append(WBCareer[x][8])
	
#WAmaster = np.array(WAmaster)
#np.savetxt('PPGdata.csv', WAmaster, delimiter = ',')


# APG
#WAmaster = WAmaster.tolist()
#for x in range(WBCareer.shape[0]):
#    WAmaster[x].append(WBCareer[x][4])

#WAmaster = np.array(WAmaster)
#np.savetxt('APGdata.csv', WAmaster, delimiter = ',')


# RPG
#WAmaster = WAmaster.tolist()
#for x in range(WBCareer.shape[0]):
#    WAmaster[x].append(WBCareer[x][3])

#WAmaster = np.array(WAmaster)
#np.savetxt('RPGdata.csv', WAmaster, delimiter = ',')

# Rockets
#WARockets = WARockets.tolist()
#np.savetxt('RocketsData.csv', WARockets, delimiter = ',')








