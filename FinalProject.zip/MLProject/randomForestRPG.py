# Random Forest Regression (RPG)
  
# importing the libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import os
os.chdir('Data')


# importing the dataset
dataSet = pd.read_csv('APGdata.csv')
x = dataSet.iloc[:, :-1].values
y = dataSet.iloc[:, 10].values


# removing values
x = np.delete(x, [1, 2, 4, 6, 7, 8], axis = 1)


# fitting random forest regression to data
from sklearn.ensemble import RandomForestRegressor
regressor = RandomForestRegressor(n_estimators = 500, random_state = 0)
regressor.fit(x, y)


# reading rockets data
dataSet = pd.read_csv('RocketsData.csv', header = None)
r = dataSet.values


# removing values
r = np.array(r)
r = np.reshape(r, (1, 10))
r = np.delete(r, [1, 2, 4, 6, 7, 8])


# feature scaling
from sklearn.preprocessing import StandardScaler
sc_r = StandardScaler()
r = sc_r.fit_transform(r.reshape(1, -1))


# making prediction
ypred = regressor.predict(r)
print(ypred)


