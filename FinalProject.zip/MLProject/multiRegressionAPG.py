# Multiple Linear Regression
  
# data Preprocessing

# importing the libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import os
os.chdir('Data')


# importing the dataset
dataSet = pd.read_csv('APGdata.csv')
x = dataSet.iloc[:, :-1].values
y = dataSet.iloc[:, 10].values


# splitting data into training and test
from sklearn.model_selection import train_test_split
xtrain, xtest, ytrain, ytest = train_test_split(x, y, test_size = 0.3, random_state = 0)


# feature scaling
from sklearn.preprocessing import StandardScaler
sc_x = StandardScaler()
xtrain = sc_x.fit_transform(xtrain)
xtest = sc_x.transform(xtest)


# fitting model to training set
from sklearn.linear_model import LinearRegression
regressor = LinearRegression()
regressor.fit(xtrain, ytrain)


# predicting the test set results
ypred = regressor.predict(xtest)


# printing correlation coefficients and p-values
from scipy.stats import pearsonr
for z in range(10):
    print('Column ', z + 1, ': ',  pearsonr(x[:, z], y))


# printing RMSE
def rmse(predictions, targets):
    return np.sqrt(((predictions - targets) ** 2).mean())

print('RMSE: ', rmse(ytest, ypred))
print(ytest)
print(ypred)


# rebuilding model to optimize RMSE
x = dataSet.iloc[:, :-1].values


# removing columns
x = pd.DataFrame(data = x)
x = x.drop(labels = [0, 1, 2, 4, 5, 8], axis = 1)


# splitting data into training and test
from sklearn.model_selection import train_test_split
xtrain, xtest, ytrain, ytest = train_test_split(x, y, test_size = 0.3, random_state = 0)


# feature scaling
from sklearn.preprocessing import StandardScaler
sc_x = StandardScaler()
xtrain = sc_x.fit_transform(xtrain)
xtest = sc_x.transform(xtest)


# fitting model to training set
from sklearn.linear_model import LinearRegression
regressor = LinearRegression()
regressor.fit(xtrain, ytrain)


# predicting the test set results
ypred = regressor.predict(xtest)


# printing RMSE
def rmse(predictions, targets):
    return np.sqrt(((predictions - targets) ** 2).mean())

print('RMSE: ', rmse(ytest, ypred))
print(ytest)
print(ypred)


# using model to predict Westbrook stats on Rockets data
dataSet = pd.read_csv('RocketsData.csv', header = None)
x = dataSet.values


# removing values
x = np.array(x)
x = np.reshape(x, (1, 10))
x = np.delete(x, [0, 1, 2, 4, 5, 8])
xcopy = np.array(x)
x = np.append(arr = x, values = xcopy)
x = np.append(arr = x, values = xcopy)
x = np.array(x)


# feature scaling
from sklearn.preprocessing import StandardScaler
sc_x = StandardScaler()
x = sc_x.fit_transform(x.reshape(1, -1))


# predicting results
x = np.reshape(x, (3, 4))
ypred = regressor.predict(x)


# printing ypred
print(ypred)

